.. automodule:: cmake_example
